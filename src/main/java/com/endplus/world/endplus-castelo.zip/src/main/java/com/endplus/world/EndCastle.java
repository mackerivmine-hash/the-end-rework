package com.endplus.world;

import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

import java.util.ArrayList;
import java.util.List;

/**
 * Castelo do Ender Dragon: uma arena circular de obsidiana com muralha, 9 torres,
 * piso com triângulo roxo e anéis em degraus por fora.
 * É construído sozinho, uma única vez, quando um jogador entra no The End.
 * Os blocos vão sendo colocados aos poucos (alguns milhares por tick) para não travar o servidor.
 */
public final class EndCastle {
	// ---------- medidas ----------
	private static final int FLOOR_Y = 64;          // altura do piso
	private static final double WALL_IN = 64.0;     // raio interno da muralha
	private static final double WALL_OUT = 66.5;    // raio externo da muralha
	private static final int WALL_H = 16;           // altura da muralha
	private static final int RING_MAX = 100;        // raio dos anéis externos
	private static final int PER_TICK = 6000;       // blocos colocados por tick

	// 9 torres: ângulo (graus) e altura
	private static final int[] TOWER_ANGLE = {20, 60, 100, 140, 180, 220, 260, 300, 340};
	private static final int[] TOWER_HEIGHT = {42, 58, 36, 64, 46, 52, 38, 60, 48};
	private static final double TOWER_R = 4.5;

	private static final BlockPos MARKER = new BlockPos(0, 61, 0);

	private record Placement(long pos, BlockState state) {}

	private static MinecraftServer lastServer;
	private static boolean done;
	private static List<Placement> queue;
	private static int cursor;
	private static final List<BlockPos> crystalSpots = new ArrayList<>();

	private EndCastle() {}

	/** Chamado todo tick do servidor. */
	public static void tick(MinecraftServer server) {
		if (server != lastServer) {   // mundo novo: zera o estado
			lastServer = server;
			done = false;
			queue = null;
			cursor = 0;
		}
		if (done) return;

		ServerLevel end = server.getLevel(Level.END);
		if (end == null) return;

		if (queue == null) {
			if (end.players().isEmpty()) return;                        // só constrói com alguém no End
			if (end.getBlockState(MARKER).is(Blocks.CRYING_OBSIDIAN)) { // já foi construído antes
				done = true;
				return;
			}
			build(end);
		}

		int n = 0;
		while (cursor < queue.size() && n < PER_TICK) {
			Placement p = queue.get(cursor++);
			end.setBlock(BlockPos.of(p.pos()), p.state(), 2);
			n++;
		}

		if (cursor >= queue.size()) {
			finish(end);
			queue = null;
			done = true;
		}
	}

	private static void put(int x, int y, int z, BlockState state) {
		queue.add(new Placement(BlockPos.asLong(x, y, z), state));
	}

	private static void build(ServerLevel level) {
		queue = new ArrayList<>(300_000);
		cursor = 0;
		crystalSpots.clear();

		BlockState air = Blocks.AIR.defaultBlockState();
		BlockState endStone = Blocks.END_STONE.defaultBlockState();
		BlockState purpur = Blocks.PURPUR_BLOCK.defaultBlockState();
		BlockState obsidian = Blocks.OBSIDIAN.defaultBlockState();
		BlockState crying = Blocks.CRYING_OBSIDIAN.defaultBlockState();
		BlockState glass = Blocks.PURPLE_STAINED_GLASS.defaultBlockState();
		BlockState bedrock = Blocks.BEDROCK.defaultBlockState();
		BlockState[] bands = {endStone, purpur, obsidian};

		// 0) remove os cristais e pilares do The End original
		AABB box = new AABB(-110, 40, -110, 110, 140, 110);
		for (Entity e : level.getEntities(EntityType.END_CRYSTAL, box, c -> true)) {
			e.discard();
		}
		BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
		for (int x = -RING_MAX; x <= RING_MAX; x++) {
			for (int z = -RING_MAX; z <= RING_MAX; z++) {
				int r2 = x * x + z * z;
				if (r2 > RING_MAX * RING_MAX) continue;
				int top = r2 <= 52 * 52 ? 112 : 72;
				for (int y = FLOOR_Y + 1; y <= top; y++) {
					m.set(x, y, z);
					if (!level.getBlockState(m).isAir()) put(x, y, z, air);
				}
			}
		}

		// triângulo do piso (vértices a 42 blocos do centro)
		double[][] v = new double[3][2];
		int[] va = {90, 210, 330};
		for (int i = 0; i < 3; i++) {
			v[i][0] = 42 * Math.cos(Math.toRadians(va[i]));
			v[i][1] = 42 * Math.sin(Math.toRadians(va[i]));
		}

		// 1) plataforma, piso decorado e anéis em degraus
		for (int x = -RING_MAX; x <= RING_MAX; x++) {
			for (int z = -RING_MAX; z <= RING_MAX; z++) {
				double r = Math.sqrt((double) x * x + (double) z * z);
				if (r <= WALL_OUT) {
					for (int y = FLOOR_Y - 3; y < FLOOR_Y; y++) put(x, y, z, endStone);
					put(x, FLOOR_Y, z, floorBlock(x, z, r, v, endStone, purpur, obsidian, crying));
				} else if (r <= RING_MAX) {
					int k = (int) ((r - WALL_OUT) / 3.0);
					int surface = FLOOR_Y - k / 3;
					BlockState mat = bands[k % 3];
					for (int y = surface - 2; y <= surface; y++) put(x, y, z, mat);
				}
			}
		}

		// 2) muralha com ameias, janelas roxas e um portão virado para o +X
		for (int x = -70; x <= 70; x++) {
			for (int z = -70; z <= 70; z++) {
				double r = Math.sqrt((double) x * x + (double) z * z);
				if (r < WALL_IN || r > WALL_OUT) continue;
				boolean gate = x > 0 && Math.abs(z) <= 6;
				double s = Math.atan2(z, x) * ((WALL_IN + WALL_OUT) / 2.0); // comprimento de arco
				double sm = ((s % 9.0) + 9.0) % 9.0;
				boolean slit = sm >= 3.0 && sm < 5.0;
				boolean gap = (((int) Math.floor((s + 1000.0) / 3.0)) & 1) == 1;
				for (int h = 1; h <= WALL_H; h++) {
					if (gate && h <= 12) continue;
					if (h == WALL_H && gap) continue;               // vãos entre as ameias
					BlockState st = obsidian;
					if (h == 2 || h == WALL_H - 1) st = crying;     // faixas roxas
					else if (slit && h >= 5 && h <= WALL_H - 3) st = glass; // janelas
					put(x, FLOOR_Y + h, z, st);
				}
			}
		}

		// 3) torres
		double mid = (WALL_IN + WALL_OUT) / 2.0;
		for (int t = 0; t < TOWER_ANGLE.length; t++) {
			int cx = (int) Math.round(mid * Math.cos(Math.toRadians(TOWER_ANGLE[t])));
			int cz = (int) Math.round(mid * Math.sin(Math.toRadians(TOWER_ANGLE[t])));
			int hgt = TOWER_HEIGHT[t];
			int topY = FLOOR_Y + hgt;
			int rad = (int) Math.ceil(TOWER_R) + 1;
			for (int dx = -rad; dx <= rad; dx++) {
				for (int dz = -rad; dz <= rad; dz++) {
					double d = Math.sqrt((double) dx * dx + (double) dz * dz);
					if (d > TOWER_R) continue;
					for (int y = FLOOR_Y + 1; y <= topY; y++) {
						BlockState st = obsidian;
						if (y == topY) st = d > 3.3 ? crying : obsidian;
						else if ((y - FLOOR_Y) % 14 == 0) st = crying; // faixas roxas na torre
						put(cx + dx, y, cz + dz, st);
					}
				}
			}
			put(cx, topY, cz, bedrock);
			crystalSpots.add(new BlockPos(cx, topY + 1, cz));
		}
	}

	private static BlockState floorBlock(int x, int z, double r, double[][] v,
			BlockState endStone, BlockState purpur, BlockState obsidian, BlockState crying) {
		if (r <= 7.0) return r <= 2.5 ? crying : purpur;

		// triângulo roxo
		double[] d = new double[3];
		for (int i = 0; i < 3; i++) {
			double[] a = v[i];
			double[] b = v[(i + 1) % 3];
			d[i] = (b[0] - a[0]) * (z - a[1]) - (b[1] - a[1]) * (x - a[0]);
		}
		boolean inside = (d[0] >= 0 && d[1] >= 0 && d[2] >= 0) || (d[0] <= 0 && d[1] <= 0 && d[2] <= 0);
		if (inside) {
			double md = Double.MAX_VALUE;
			for (int i = 0; i < 3; i++) {
				double[] a = v[i];
				double[] b = v[(i + 1) % 3];
				double len = Math.hypot(b[0] - a[0], b[1] - a[1]);
				md = Math.min(md, Math.abs(d[i]) / len);
			}
			return md < 1.5 ? crying : purpur;
		}
		if (r >= 46.0 && r <= 48.5) return obsidian;
		if (r >= 50.0 && r <= 51.0) return purpur;
		return endStone;
	}

	private static void finish(ServerLevel level) {
		for (BlockPos p : crystalSpots) {
			Entity crystal = EntityType.END_CRYSTAL.create(level, EntitySpawnReason.EVENT);
			if (crystal != null) {
				crystal.setPos(p.getX() + 0.5, p.getY(), p.getZ() + 0.5);
				level.addFreshEntity(crystal);
			}
		}
		// o marcador vai por último: se o servidor fechar no meio, ele reconstrói na próxima vez
		level.setBlock(MARKER, Blocks.CRYING_OBSIDIAN.defaultBlockState(), 2);
	}
}
